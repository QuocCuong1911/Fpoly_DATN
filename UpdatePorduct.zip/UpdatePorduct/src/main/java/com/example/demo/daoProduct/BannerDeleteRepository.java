package com.example.demo.daoProduct;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.BannerEntity;



public interface BannerDeleteRepository extends JpaRepository<BannerEntity , Integer>{

}
