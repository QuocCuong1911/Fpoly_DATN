package com.example.demo.daoProduct;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.ProductEntity;

public interface DaoProudct extends JpaRepository<ProductEntity, Integer>{

}
