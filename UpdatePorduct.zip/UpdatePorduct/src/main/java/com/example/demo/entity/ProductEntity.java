package com.example.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Product")
public class ProductEntity {
	@Id
	private Integer ProductID;

	private String Name;

	private String Description;

	private Double Price;

	
	private Integer CategoryID;
	
	private Integer Quati;
    
}
