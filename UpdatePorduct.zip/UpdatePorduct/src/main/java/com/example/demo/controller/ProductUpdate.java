package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.entity.ProductEntity;
import com.example.demo.impl.BannerDeleteServicelmpl;
import com.example.demo.impl.ProductServiceOverdive;


@RestController
@RequestMapping("index")
public class ProductUpdate {
@Autowired
BannerDeleteServicelmpl bannerserviec;
@Autowired
ProductServiceOverdive daoP;

@GetMapping()
public ResponseEntity<?> getAll(){
	return ResponseEntity.ok(daoP.findAll());
}
@PostMapping("/update")
public ResponseEntity<?> update(@RequestBody ProductEntity Pe){
	return ResponseEntity.ok(daoP.save(Pe));
}

@DeleteMapping("/delete/{banner}")
public ResponseEntity<?> delete(@PathVariable int banner){
	return ResponseEntity.ok(bannerserviec.delete(banner));
}
}
