package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.ProductEntity;


public interface ProductServiece {
	ProductEntity save(ProductEntity product);
	ProductEntity update(ProductEntity student);

	List<ProductEntity> findAll();
}
