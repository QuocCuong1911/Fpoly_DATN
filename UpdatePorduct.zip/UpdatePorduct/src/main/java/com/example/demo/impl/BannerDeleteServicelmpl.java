package com.example.demo.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.daoProduct.BannerDeleteRepository;
import com.example.demo.entity.BannerEntity;
import com.example.demo.service.BannerService;

@Service
public class BannerDeleteServicelmpl implements BannerService{
	@Autowired
     BannerDeleteRepository dao;
	@Override
	public List<BannerEntity> findAll() {
		return dao.findAll();
	}

	@Override
	public BannerEntity delete(Integer banner) {
		Optional<BannerEntity> Optional = dao.findById(banner);
		return Optional.map(o -> {dao.delete(o);
		return o ;
		}).orElse(null);
	}

}
