package com.example.demo.entity;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
 @Entity
@Table(name = "Banners")
public class BannerEntity {
	@Id
	private Integer BannerID ;
	private String ImageURL;
	private String Caption;
	private Integer OrderB;
	private Date datter;
	private Integer UserID;
}
