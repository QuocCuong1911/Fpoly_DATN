package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpdatePorductApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpdatePorductApplication.class, args);
	}

}
