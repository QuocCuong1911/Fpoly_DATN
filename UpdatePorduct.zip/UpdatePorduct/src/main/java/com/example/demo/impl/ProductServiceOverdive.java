package com.example.demo.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.daoProduct.DaoProudct;
import com.example.demo.entity.ProductEntity;
import com.example.demo.service.ProductServiece;

@Service
public class ProductServiceOverdive  implements ProductServiece{
	@Autowired
	DaoProudct DaoP;
	@Override
	public ProductEntity save(ProductEntity product) {

		return DaoP.save(product);
	}

	@Override
	public ProductEntity update(ProductEntity product) {

		return DaoP.save(product);
	}

	@Override
	public List<ProductEntity> findAll() {

		return DaoP.findAll();
	}

}
