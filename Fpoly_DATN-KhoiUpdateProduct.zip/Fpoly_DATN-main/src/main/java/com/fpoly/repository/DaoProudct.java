package com.fpoly.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fpoly.entity.ProductEntity;



public interface DaoProudct extends JpaRepository<ProductEntity, Integer>{

}
