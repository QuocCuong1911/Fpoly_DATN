package com.fpoly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FpolyDatnApplication {

	public static void main(String[] args) {
		SpringApplication.run(FpolyDatnApplication.class, args);
	}

}
