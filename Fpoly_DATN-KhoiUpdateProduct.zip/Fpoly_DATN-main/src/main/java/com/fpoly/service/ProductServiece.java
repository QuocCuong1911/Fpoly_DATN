package com.fpoly.service;

import java.util.List;

import com.fpoly.entity.ProductEntity;




public interface ProductServiece {
	ProductEntity save(ProductEntity product);
	ProductEntity update(ProductEntity student);

	List<ProductEntity> findAll();
}
