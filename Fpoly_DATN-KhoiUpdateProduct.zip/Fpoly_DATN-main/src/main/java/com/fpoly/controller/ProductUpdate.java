package com.fpoly.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fpoly.entity.ProductEntity;
import com.fpoly.serviceimpl.ProductServiceOverdive;


@RestController
@RequestMapping("index")
public class ProductUpdate {
@Autowired
ProductServiceOverdive daoP;

@GetMapping()
public ResponseEntity<?> getAll(){
	return ResponseEntity.ok(daoP.findAll());
}
@PostMapping("/update")
public ResponseEntity<?> update(@RequestBody ProductEntity Pe){
	return ResponseEntity.ok(daoP.save(Pe));
}
}
